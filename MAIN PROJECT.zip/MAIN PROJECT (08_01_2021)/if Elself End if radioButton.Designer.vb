﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class if_Elself_End_if_radioButton
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.RbSate = New System.Windows.Forms.RadioButton()
        Me.RbSoto = New System.Windows.Forms.RadioButton()
        Me.RbKare = New System.Windows.Forms.RadioButton()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'RbSate
        '
        Me.RbSate.AutoSize = True
        Me.RbSate.Location = New System.Drawing.Point(27, 19)
        Me.RbSate.Name = "RbSate"
        Me.RbSate.Size = New System.Drawing.Size(47, 17)
        Me.RbSate.TabIndex = 0
        Me.RbSate.TabStop = True
        Me.RbSate.Text = "Sate"
        Me.RbSate.UseVisualStyleBackColor = True
        '
        'RbSoto
        '
        Me.RbSoto.AutoSize = True
        Me.RbSoto.Location = New System.Drawing.Point(27, 52)
        Me.RbSoto.Name = "RbSoto"
        Me.RbSoto.Size = New System.Drawing.Size(45, 17)
        Me.RbSoto.TabIndex = 1
        Me.RbSoto.TabStop = True
        Me.RbSoto.Text = "soto"
        Me.RbSoto.UseVisualStyleBackColor = True
        '
        'RbKare
        '
        Me.RbKare.AutoSize = True
        Me.RbKare.Location = New System.Drawing.Point(27, 88)
        Me.RbKare.Name = "RbKare"
        Me.RbKare.Size = New System.Drawing.Size(47, 17)
        Me.RbKare.TabIndex = 2
        Me.RbKare.TabStop = True
        Me.RbKare.Text = "Kare"
        Me.RbKare.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(89, 174)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(123, 40)
        Me.Button1.TabIndex = 3
        Me.Button1.Text = "Tampilkan pilihan"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.RbKare)
        Me.GroupBox1.Controls.Add(Me.RbSoto)
        Me.GroupBox1.Controls.Add(Me.RbSate)
        Me.GroupBox1.Location = New System.Drawing.Point(89, 38)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(124, 120)
        Me.GroupBox1.TabIndex = 4
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Pilihan Radio Button"
        '
        'if_Elself_End_if_radioButton
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.ClientSize = New System.Drawing.Size(314, 249)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Button1)
        Me.Name = "if_Elself_End_if_radioButton"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "if_Elself_End_if_radioButton"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents RbSate As RadioButton
    Friend WithEvents RbSoto As RadioButton
    Friend WithEvents RbKare As RadioButton
    Friend WithEvents Button1 As Button
    Friend WithEvents GroupBox1 As GroupBox
End Class
