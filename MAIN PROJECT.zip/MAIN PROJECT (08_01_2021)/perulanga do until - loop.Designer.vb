﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class perulanga_do_until___loop
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.Bproses = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'ListBox1
        '
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.Location = New System.Drawing.Point(97, 106)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(120, 173)
        Me.ListBox1.TabIndex = 7
        '
        'Bproses
        '
        Me.Bproses.BackColor = System.Drawing.Color.DodgerBlue
        Me.Bproses.FlatAppearance.BorderSize = 0
        Me.Bproses.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Bproses.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Bproses.ForeColor = System.Drawing.Color.White
        Me.Bproses.Location = New System.Drawing.Point(60, 43)
        Me.Bproses.Name = "Bproses"
        Me.Bproses.Size = New System.Drawing.Size(189, 39)
        Me.Bproses.TabIndex = 6
        Me.Bproses.Text = "&Proses"
        Me.Bproses.UseVisualStyleBackColor = False
        '
        'perulanga_do_until___loop
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(315, 309)
        Me.Controls.Add(Me.ListBox1)
        Me.Controls.Add(Me.Bproses)
        Me.Name = "perulanga_do_until___loop"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "perulanga_do_until___loop"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents ListBox1 As Windows.Forms.ListBox
    Friend WithEvents Bproses As Button
End Class
