﻿Imports System.Data
Imports System.Data.OleDb
Public Class InputForm
    Sub BERSIH()
        tNIP.Text = ""
        tNama.Text = ""
        tAlamat.Text = ""
        cbBagian.Text = "Silahkan Pilih"
        cbPendidikan.Text = "Silahkan Pilih"
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Dim kawin As String

        If tNIP.Text = "" Or tNama.Text = "" Then
            MsgBox("Isi data dengan benar", MsgBoxStyle.Exclamation, "Kesalahan")
            Exit Sub
        End If
        If rbBelumNikah.Checked = True Then
            kawin = "Belum Menikah"
        Else
            kawin = "Menikah"
        End If
        CNN = New OleDbConnection(KONEKSI)
        If CNN.State <> ConnectionState.Closed Then CNN.Close()
        CNN.Open()
        OLECMD = New OleDbCommand("insert into pegawai (NIP,NamaPgw,Bagian,TglLhr, Alamat, Pendidikan, Status) values ('" & tNIP.Text & "', '" & tNama.Text & "', '" & cbBagian.Text & "', '" & DateTimePicker1.Text & "', '" & tAlamat.Text & "', '" & cbPendidikan.Text & "', '" & kawin & "') ", CNN)

        X = OLECMD.ExecuteNonQuery
        If X = 1 Then
            MsgBox("Data Berhasil di Simpan!", MsgBoxStyle.Information, "Tersimpan")
            Call BERSIH()
            tNIP.Focus()
        Else
            MsgBox("Gagal menyimpan data!!", MsgBoxStyle.Exclamation, "GAGAL")
        End If

    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Call BERSIH()
        btnSave.Enabled = True
        btnEdit.Enabled = False
        btnDelete.Enabled = False
        tNIP.Enabled = True
        tNIP.Focus()

    End Sub

    Private Sub tNIP_KeyPress(sender As Object, e As KeyPressEventArgs) Handles tNIP.KeyPress
        If Asc(e.KeyChar) = 13 Then
            tNama.Focus()
        End If
    End Sub

    Private Sub tNama_KeyPress(sender As Object, e As KeyPressEventArgs) Handles tNama.KeyPress
        If Asc(e.KeyChar) = 13 Then
            cbBagian.Focus()
        End If
    End Sub

    Private Sub btnEdit_Click(sender As Object, e As EventArgs) Handles btnEdit.Click
        Dim kawin As String

        If tNIP.Text = "" Or tNama.Text = "" Then
            MsgBox("Isi data dengan benar", MsgBoxStyle.Exclamation, "Kesalahan")
            Exit Sub
        End If
        If rbBelumNikah.Checked = True Then
            kawin = "Belum Menikah"
        Else
            kawin = "Menikah"
        End If

        CNN = New OleDbConnection(KONEKSI)
        If CNN.State <> ConnectionState.Closed Then CNN.Close()
        CNN.Open()
        OLECMD = New OleDbCommand("Update pegawai set NamaPgw = '" & tNama.Text & "', Bagian = '" & cbBagian.Text & "', TglLhr = '" & DateTimePicker1.Text & "' , Alamat = '" & tAlamat.Text & "', Pendidikan = '" & cbPendidikan.Text & "' , Status = '" & kawin & "' where NIP = '" & tNIP.Text & "'", CNN)

        X = OLECMD.ExecuteNonQuery
        If X = 1 Then
            MsgBox("Data Berhasil di Edit!", MsgBoxStyle.Information, "UPDATE BERHASIL")
            Call BERSIH()
            tNIP.Focus()
        Else
            MsgBox("Gagal mengedit data!!", MsgBoxStyle.Exclamation, "GAGAL")
        End If
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If MsgBox("Apakah Anda yakin ingin menghapus data?", MsgBoxStyle.YesNo, "Konfirmasi") = MsgBoxResult.Yes Then
            CNN = New OleDbConnection(KONEKSI)
            If CNN.State <> ConnectionState.Closed Then CNN.Close()
            CNN.Open()
            OLECMD = New OleDbCommand("delete from pegawai where NIP = '" & tNIP.Text & "'", CNN)
            X = OLECMD.ExecuteNonQuery
            If X = 1 Then
                Call BERSIH()
                btnSave.Enabled = True
                btnEdit.Enabled = False
                btnDelete.Enabled = False
                tNIP.Focus()
            Else
                MsgBox("Gagal menghapus data", MsgBoxStyle.Exclamation, "GAGAL")
            End If
        End If

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Dispose()
    End Sub

    Private Sub btnCari_Click(sender As Object, e As EventArgs) Handles btnCari.Click
        Dim poppegawai As New poppeg
        poppegawai.ShowDialog()
        If poppegawai.colNama <> "" Then
            tNIP.Text = poppegawai.colNIP
            tNama.Text = poppegawai.colNama
            cbBagian.Text = poppegawai.colbgn
            DateTimePicker1.Text = poppegawai.coltgllhr
            tAlamat.Text = poppegawai.colAlamat
            cbPendidikan.Text = poppegawai.colpend
            If poppegawai.colstatus = "Menikah" Then
                rbNikah.Checked = True
            Else
                rbBelumNikah.Checked = True
            End If
            tNIP.Enabled = False
            tNama.Focus()
        End If
        btnEdit.Enabled = True
        btnDelete.Enabled = True
    End Sub


End Class