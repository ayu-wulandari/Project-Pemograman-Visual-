﻿Public Class perulangan_for_next___step__
    Private Sub Bproses_Click(sender As Object, e As EventArgs) Handles Bproses.Click
        Dim i As Integer
        ListBox1.Items.Clear()
        For i = 10 To 1 Step -1
            ListBox1.Items.Add(i)
        Next
    End Sub
End Class