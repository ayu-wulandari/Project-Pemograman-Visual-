﻿Public Class ListBox
    Private Sub ListBox_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ListBox1.Items.Add("Jeruk")
        ListBox1.Items.Add("Alpukat")
        ListBox1.Items.Add("Strawberry")
        ListBox1.Items.Add("Semangka")
        ListBox1.Items.Add("Kelengkeng")
        ListBox1.Items.Add("Kedondong")
        ListBox1.Items.Add("Durian")
        ListBox1.Items.Add("Pepaya")
        ListBox1.Items.Add("Rambutan")
        ListBox1.Items.Add("Mangga")
        ListBox1.Items.Add("Pisang")
    End Sub

    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox1.SelectedIndexChanged
        Select Case ListBox1.SelectedIndex
            Case 0
                Label2.Text = "Banyak mengandung vitamin C"
            Case 1
                Label2.Text = "Salah satu buah yang mengandung lemak"
            Case 2
                Label2.Text = "Jenis buah yang hanya tumbuh di dataran tinggi"
            Case 3
                Label2.Text = "Salah satu jenis buah yang banyak mengandung air"
            Case 4
                Label2.Text = "Jenis buah kecil yang memiliki biji yang keras"
            Case 5
                Label2.Text = "Buah yang biasa digunakan untuk campuran rujak"
            Case 6
                Label2.Text = "Buah yang memiliki bau yang khas"
            Case 7
                Label2.Text = "Buah yang memiliki banyak manfaat bagi sistem pencernaan"
            Case 8
                Label2.Text = "Buah yang memiliki bulu dibagian kulitnya"
            Case 9
                Label2.Text = "Buah yang berjenis monokotil atau berbiji tunggal"
            Case 10
                Label2.Text = "Buah yang memiliki tekstur daging buah yang lembut"

        End Select
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub
End Class