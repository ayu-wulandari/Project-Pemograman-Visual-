﻿Public Class Perulangan_Do_While_Loop
    Private Sub btnProses_Click(sender As Object, e As EventArgs) Handles btnProses.Click
        Dim i As Integer
        ListBox1.Items.Clear()
        i = 1
        Do While i <= 10
            ListBox1.Items.Add(i)
            i += 1
        Loop

    End Sub
End Class