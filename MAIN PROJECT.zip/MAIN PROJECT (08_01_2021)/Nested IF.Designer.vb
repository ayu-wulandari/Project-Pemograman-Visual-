﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Nested_IF
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Texket = New System.Windows.Forms.TextBox()
        Me.Cmdproses = New System.Windows.Forms.Button()
        Me.cmbstatus = New System.Windows.Forms.ComboBox()
        Me.RBW = New System.Windows.Forms.RadioButton()
        Me.RBP = New System.Windows.Forms.RadioButton()
        Me.LabelKeterangan = New System.Windows.Forms.Label()
        Me.LabelStatus = New System.Windows.Forms.Label()
        Me.LabelGender = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Texket
        '
        Me.Texket.Enabled = False
        Me.Texket.Location = New System.Drawing.Point(212, 185)
        Me.Texket.Margin = New System.Windows.Forms.Padding(2)
        Me.Texket.Name = "Texket"
        Me.Texket.Size = New System.Drawing.Size(107, 20)
        Me.Texket.TabIndex = 15
        '
        'Cmdproses
        '
        Me.Cmdproses.BackColor = System.Drawing.Color.DodgerBlue
        Me.Cmdproses.FlatAppearance.BorderSize = 0
        Me.Cmdproses.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Cmdproses.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmdproses.ForeColor = System.Drawing.Color.White
        Me.Cmdproses.Location = New System.Drawing.Point(85, 135)
        Me.Cmdproses.Margin = New System.Windows.Forms.Padding(2)
        Me.Cmdproses.Name = "Cmdproses"
        Me.Cmdproses.Size = New System.Drawing.Size(234, 27)
        Me.Cmdproses.TabIndex = 14
        Me.Cmdproses.Text = "Proses"
        Me.Cmdproses.UseVisualStyleBackColor = False
        '
        'cmbstatus
        '
        Me.cmbstatus.FormattingEnabled = True
        Me.cmbstatus.Location = New System.Drawing.Point(212, 98)
        Me.cmbstatus.Margin = New System.Windows.Forms.Padding(2)
        Me.cmbstatus.Name = "cmbstatus"
        Me.cmbstatus.Size = New System.Drawing.Size(107, 21)
        Me.cmbstatus.TabIndex = 13
        '
        'RBW
        '
        Me.RBW.AutoSize = True
        Me.RBW.Location = New System.Drawing.Point(260, 62)
        Me.RBW.Margin = New System.Windows.Forms.Padding(2)
        Me.RBW.Name = "RBW"
        Me.RBW.Size = New System.Drawing.Size(59, 17)
        Me.RBW.TabIndex = 12
        Me.RBW.TabStop = True
        Me.RBW.Text = "Wanita"
        Me.RBW.UseVisualStyleBackColor = True
        '
        'RBP
        '
        Me.RBP.AutoSize = True
        Me.RBP.Location = New System.Drawing.Point(212, 63)
        Me.RBP.Margin = New System.Windows.Forms.Padding(2)
        Me.RBP.Name = "RBP"
        Me.RBP.Size = New System.Drawing.Size(43, 17)
        Me.RBP.TabIndex = 11
        Me.RBP.TabStop = True
        Me.RBP.Text = "Pria"
        Me.RBP.UseVisualStyleBackColor = True
        '
        'LabelKeterangan
        '
        Me.LabelKeterangan.AutoSize = True
        Me.LabelKeterangan.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelKeterangan.ForeColor = System.Drawing.Color.SteelBlue
        Me.LabelKeterangan.Location = New System.Drawing.Point(83, 185)
        Me.LabelKeterangan.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LabelKeterangan.Name = "LabelKeterangan"
        Me.LabelKeterangan.Size = New System.Drawing.Size(72, 13)
        Me.LabelKeterangan.TabIndex = 10
        Me.LabelKeterangan.Text = "Keterangan"
        '
        'LabelStatus
        '
        Me.LabelStatus.AutoSize = True
        Me.LabelStatus.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelStatus.ForeColor = System.Drawing.Color.SteelBlue
        Me.LabelStatus.Location = New System.Drawing.Point(82, 103)
        Me.LabelStatus.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LabelStatus.Name = "LabelStatus"
        Me.LabelStatus.Size = New System.Drawing.Size(43, 13)
        Me.LabelStatus.TabIndex = 9
        Me.LabelStatus.Text = "Status"
        '
        'LabelGender
        '
        Me.LabelGender.AutoSize = True
        Me.LabelGender.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelGender.ForeColor = System.Drawing.Color.SteelBlue
        Me.LabelGender.Location = New System.Drawing.Point(82, 63)
        Me.LabelGender.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LabelGender.Name = "LabelGender"
        Me.LabelGender.Size = New System.Drawing.Size(48, 13)
        Me.LabelGender.TabIndex = 8
        Me.LabelGender.Text = "Gender"
        '
        'Nested_IF
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(404, 288)
        Me.Controls.Add(Me.Texket)
        Me.Controls.Add(Me.Cmdproses)
        Me.Controls.Add(Me.cmbstatus)
        Me.Controls.Add(Me.RBW)
        Me.Controls.Add(Me.RBP)
        Me.Controls.Add(Me.LabelKeterangan)
        Me.Controls.Add(Me.LabelStatus)
        Me.Controls.Add(Me.LabelGender)
        Me.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Name = "Nested_IF"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Nested_IF"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Texket As TextBox
    Friend WithEvents Cmdproses As Button
    Friend WithEvents cmbstatus As ComboBox
    Friend WithEvents RBW As RadioButton
    Friend WithEvents RBP As RadioButton
    Friend WithEvents LabelKeterangan As Label
    Friend WithEvents LabelStatus As Label
    Friend WithEvents LabelGender As Label
End Class
