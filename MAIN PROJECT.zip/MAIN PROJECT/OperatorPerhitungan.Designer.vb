﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Operator_Perhitungan
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Hasil = New System.Windows.Forms.Button()
        Me.Keluar = New System.Windows.Forms.Button()
        Me.Pertama = New System.Windows.Forms.TextBox()
        Me.Kedua = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Bagi = New System.Windows.Forms.Button()
        Me.Kali = New System.Windows.Forms.Button()
        Me.Kurang = New System.Windows.Forms.Button()
        Me.Tambah = New System.Windows.Forms.Button()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial Rounded MT Bold", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(3, 33)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(106, 15)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Angka Pertama"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Arial Rounded MT Bold", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(3, 90)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(92, 15)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Angka Kedua"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Arial Rounded MT Bold", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(3, 195)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(133, 15)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Hasil Dari Operator"
        '
        'Hasil
        '
        Me.Hasil.Location = New System.Drawing.Point(109, 237)
        Me.Hasil.Name = "Hasil"
        Me.Hasil.Size = New System.Drawing.Size(75, 23)
        Me.Hasil.TabIndex = 3
        Me.Hasil.Text = "Clear"
        Me.Hasil.UseVisualStyleBackColor = True
        '
        'Keluar
        '
        Me.Keluar.Location = New System.Drawing.Point(215, 236)
        Me.Keluar.Name = "Keluar"
        Me.Keluar.Size = New System.Drawing.Size(75, 23)
        Me.Keluar.TabIndex = 4
        Me.Keluar.Text = "Keluar"
        Me.Keluar.UseVisualStyleBackColor = True
        '
        'Pertama
        '
        Me.Pertama.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.Pertama.Location = New System.Drawing.Point(126, 33)
        Me.Pertama.Name = "Pertama"
        Me.Pertama.Size = New System.Drawing.Size(124, 20)
        Me.Pertama.TabIndex = 5
        '
        'Kedua
        '
        Me.Kedua.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.Kedua.Location = New System.Drawing.Point(126, 85)
        Me.Kedua.Name = "Kedua"
        Me.Kedua.Size = New System.Drawing.Size(124, 20)
        Me.Kedua.TabIndex = 6
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Bagi)
        Me.GroupBox1.Controls.Add(Me.Kali)
        Me.GroupBox1.Controls.Add(Me.Kurang)
        Me.GroupBox1.Controls.Add(Me.Tambah)
        Me.GroupBox1.Location = New System.Drawing.Point(70, 122)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(220, 58)
        Me.GroupBox1.TabIndex = 7
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Operator"
        '
        'Bagi
        '
        Me.Bagi.Font = New System.Drawing.Font("Microsoft PhagsPa", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Bagi.Location = New System.Drawing.Point(170, 21)
        Me.Bagi.Name = "Bagi"
        Me.Bagi.Size = New System.Drawing.Size(26, 23)
        Me.Bagi.TabIndex = 3
        Me.Bagi.Text = ":"
        Me.Bagi.UseVisualStyleBackColor = True
        '
        'Kali
        '
        Me.Kali.Font = New System.Drawing.Font("Microsoft PhagsPa", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Kali.Location = New System.Drawing.Point(120, 21)
        Me.Kali.Name = "Kali"
        Me.Kali.Size = New System.Drawing.Size(23, 23)
        Me.Kali.TabIndex = 2
        Me.Kali.Text = "x"
        Me.Kali.UseVisualStyleBackColor = True
        '
        'Kurang
        '
        Me.Kurang.Font = New System.Drawing.Font("Microsoft PhagsPa", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Kurang.Location = New System.Drawing.Point(70, 21)
        Me.Kurang.Name = "Kurang"
        Me.Kurang.Size = New System.Drawing.Size(25, 23)
        Me.Kurang.TabIndex = 1
        Me.Kurang.Text = "-"
        Me.Kurang.UseVisualStyleBackColor = True
        '
        'Tambah
        '
        Me.Tambah.Font = New System.Drawing.Font("Microsoft PhagsPa", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tambah.Location = New System.Drawing.Point(19, 21)
        Me.Tambah.Name = "Tambah"
        Me.Tambah.Size = New System.Drawing.Size(26, 23)
        Me.Tambah.TabIndex = 0
        Me.Tambah.Text = "+"
        Me.Tambah.UseVisualStyleBackColor = True
        '
        'TextBox1
        '
        Me.TextBox1.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.TextBox1.Location = New System.Drawing.Point(146, 196)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(144, 20)
        Me.TextBox1.TabIndex = 8
        '
        'Operator_Perhitungan
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.ClientSize = New System.Drawing.Size(335, 274)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Kedua)
        Me.Controls.Add(Me.Pertama)
        Me.Controls.Add(Me.Keluar)
        Me.Controls.Add(Me.Hasil)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Operator_Perhitungan"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "OperatorPerhitungan"
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Hasil As Button
    Friend WithEvents Keluar As Button
    Friend WithEvents Pertama As TextBox
    Friend WithEvents Kedua As TextBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Bagi As Button
    Friend WithEvents Kali As Button
    Friend WithEvents Kurang As Button
    Friend WithEvents Tambah As Button
    Friend WithEvents TextBox1 As TextBox
End Class
