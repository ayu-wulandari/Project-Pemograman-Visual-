﻿Public Class Operator_Perhitungan
    Private Sub Pertama_TextChanged(sender As Object, e As EventArgs) Handles Pertama.TextChanged

    End Sub

    Private Sub Tambah_Click(sender As Object, e As EventArgs) Handles Tambah.Click
        TextBox1.Text = Val(Pertama.Text) + Val(Kedua.Text)
    End Sub

    Private Sub Kurang_Click(sender As Object, e As EventArgs) Handles Kurang.Click
        TextBox1.Text = Val(Pertama.Text) - Val(Kedua.Text)
    End Sub

    Private Sub Kali_Click(sender As Object, e As EventArgs) Handles Kali.Click
        TextBox1.Text = Val(Pertama.Text) * Val(Kedua.Text)

    End Sub

    Private Sub Bagi_Click(sender As Object, e As EventArgs) Handles Bagi.Click
        TextBox1.Text = Val(Pertama.Text) / Val(Kedua.Text)
    End Sub

    Private Sub Hasil_Click(sender As Object, e As EventArgs) Handles Hasil.Click
        Pertama.Text = ""
        Kedua.Text = ""
        TextBox1.Text = ""

    End Sub

    Private Sub Keluar_Click(sender As Object, e As EventArgs) Handles Keluar.Click
        Me.Close()

    End Sub
End Class