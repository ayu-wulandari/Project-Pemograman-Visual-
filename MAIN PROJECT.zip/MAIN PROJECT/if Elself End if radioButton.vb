﻿Public Class if_Elself_End_if_radioButton
    Private Sub if_Elself_End_if_radioButton_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim pilihan = " Anda memilih "
        If RbSate.Checked = True Then
            pilihan = pilihan & "Sate"
        End If
        If RbSoto.Checked = True Then
            pilihan = pilihan & "Soto"
        End If
        If RbKare.Checked = True Then
            pilihan = pilihan & "Kare"
        End If
        MsgBox(pilihan & ", pesan segera diantar")
    End Sub
End Class