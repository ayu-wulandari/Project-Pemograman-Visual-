﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.Pertemuan1ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelloWorldToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MessageBoxToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Pertemuan2ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OperatorRelasiToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ChangeKursToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OperatorPerhitungan1ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OperatorPerhitungan2ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ConvertTipeDataToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PembayaranToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Pertemuan3ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.IfThenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.IfThenElseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.IfElseIfEndIfCheckboxToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.IfElseIfEndIfRadiobuttonToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.IfElseIfEndIfComboboxToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NestedIfToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EntryDataMahasiswaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PercabanganIfToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Pertemuan4ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SelectCaseListBoxToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SelectCasePaketMakananToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SelectCaseJurusanToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SelectCaseNilaiToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PerhitunganNilaiAkhirDanPenentuanGradeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PerhitunganGajiKaryawanToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ProgramSPBUToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PertemuanToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PerulanganForNextToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PerulanganForNextStepToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PerulanganForNextDateToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PerulanganForNextInputToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PerulanganDoWhileLoopToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PerulanganDoUntilLoopToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PerulanganWhileEndWhileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PracticeLatihan1ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Pertemuan6ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.IndexArrayComboBoxToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BulanIndexToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MaskapaiPenerbanganToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PracticeOfArray01ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TampilanDataToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PracticeOfArray02ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Pertemuan8ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Pretemuan9ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Pertemuan10ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Pertemuan11ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Pertemuan12ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Pertemuan13ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Pertemuan14ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.StatusStrip2 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel3 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.MenuStrip1.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        Me.StatusStrip2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.AutoSize = False
        Me.MenuStrip1.BackColor = System.Drawing.Color.FromArgb(CType(CType(216, Byte), Integer), CType(CType(196, Byte), Integer), CType(CType(212, Byte), Integer))
        Me.MenuStrip1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.MenuStrip1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Pertemuan1ToolStripMenuItem, Me.Pertemuan2ToolStripMenuItem, Me.Pertemuan3ToolStripMenuItem, Me.Pertemuan4ToolStripMenuItem, Me.PertemuanToolStripMenuItem, Me.Pertemuan6ToolStripMenuItem, Me.Pertemuan8ToolStripMenuItem, Me.Pretemuan9ToolStripMenuItem, Me.Pertemuan10ToolStripMenuItem, Me.Pertemuan11ToolStripMenuItem, Me.Pertemuan12ToolStripMenuItem, Me.Pertemuan13ToolStripMenuItem, Me.Pertemuan14ToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1604, 50)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'Pertemuan1ToolStripMenuItem
        '
        Me.Pertemuan1ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.HelloWorldToolStripMenuItem, Me.MessageBoxToolStripMenuItem})
        Me.Pertemuan1ToolStripMenuItem.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pertemuan1ToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer))
        Me.Pertemuan1ToolStripMenuItem.Name = "Pertemuan1ToolStripMenuItem"
        Me.Pertemuan1ToolStripMenuItem.Size = New System.Drawing.Size(119, 46)
        Me.Pertemuan1ToolStripMenuItem.Text = "Pertemuan 1"
        '
        'HelloWorldToolStripMenuItem
        '
        Me.HelloWorldToolStripMenuItem.BackColor = System.Drawing.Color.White
        Me.HelloWorldToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.HelloWorldToolStripMenuItem.Name = "HelloWorldToolStripMenuItem"
        Me.HelloWorldToolStripMenuItem.Size = New System.Drawing.Size(192, 28)
        Me.HelloWorldToolStripMenuItem.Text = "Hello World!"
        '
        'MessageBoxToolStripMenuItem
        '
        Me.MessageBoxToolStripMenuItem.BackColor = System.Drawing.Color.White
        Me.MessageBoxToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.MessageBoxToolStripMenuItem.Name = "MessageBoxToolStripMenuItem"
        Me.MessageBoxToolStripMenuItem.Size = New System.Drawing.Size(192, 28)
        Me.MessageBoxToolStripMenuItem.Text = "MessageBox"
        '
        'Pertemuan2ToolStripMenuItem
        '
        Me.Pertemuan2ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.OperatorRelasiToolStripMenuItem, Me.ChangeKursToolStripMenuItem, Me.OperatorPerhitungan1ToolStripMenuItem, Me.OperatorPerhitungan2ToolStripMenuItem, Me.ConvertTipeDataToolStripMenuItem, Me.PembayaranToolStripMenuItem})
        Me.Pertemuan2ToolStripMenuItem.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pertemuan2ToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer))
        Me.Pertemuan2ToolStripMenuItem.Name = "Pertemuan2ToolStripMenuItem"
        Me.Pertemuan2ToolStripMenuItem.Size = New System.Drawing.Size(119, 46)
        Me.Pertemuan2ToolStripMenuItem.Text = "Pertemuan 2"
        '
        'OperatorRelasiToolStripMenuItem
        '
        Me.OperatorRelasiToolStripMenuItem.Name = "OperatorRelasiToolStripMenuItem"
        Me.OperatorRelasiToolStripMenuItem.Size = New System.Drawing.Size(271, 28)
        Me.OperatorRelasiToolStripMenuItem.Text = "Operator Relasi"
        '
        'ChangeKursToolStripMenuItem
        '
        Me.ChangeKursToolStripMenuItem.Name = "ChangeKursToolStripMenuItem"
        Me.ChangeKursToolStripMenuItem.Size = New System.Drawing.Size(271, 28)
        Me.ChangeKursToolStripMenuItem.Text = "Change Kurs"
        '
        'OperatorPerhitungan1ToolStripMenuItem
        '
        Me.OperatorPerhitungan1ToolStripMenuItem.Name = "OperatorPerhitungan1ToolStripMenuItem"
        Me.OperatorPerhitungan1ToolStripMenuItem.Size = New System.Drawing.Size(271, 28)
        Me.OperatorPerhitungan1ToolStripMenuItem.Text = "Operator Perhitungan 1"
        '
        'OperatorPerhitungan2ToolStripMenuItem
        '
        Me.OperatorPerhitungan2ToolStripMenuItem.Name = "OperatorPerhitungan2ToolStripMenuItem"
        Me.OperatorPerhitungan2ToolStripMenuItem.Size = New System.Drawing.Size(271, 28)
        Me.OperatorPerhitungan2ToolStripMenuItem.Text = "Operator Perhitungan 2"
        '
        'ConvertTipeDataToolStripMenuItem
        '
        Me.ConvertTipeDataToolStripMenuItem.Name = "ConvertTipeDataToolStripMenuItem"
        Me.ConvertTipeDataToolStripMenuItem.Size = New System.Drawing.Size(271, 28)
        Me.ConvertTipeDataToolStripMenuItem.Text = "Convert Tipe Data"
        '
        'PembayaranToolStripMenuItem
        '
        Me.PembayaranToolStripMenuItem.Name = "PembayaranToolStripMenuItem"
        Me.PembayaranToolStripMenuItem.Size = New System.Drawing.Size(271, 28)
        Me.PembayaranToolStripMenuItem.Text = "Pembayaran"
        '
        'Pertemuan3ToolStripMenuItem
        '
        Me.Pertemuan3ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.IfThenToolStripMenuItem, Me.IfThenElseToolStripMenuItem, Me.IfElseIfEndIfCheckboxToolStripMenuItem, Me.IfElseIfEndIfRadiobuttonToolStripMenuItem, Me.IfElseIfEndIfComboboxToolStripMenuItem, Me.NestedIfToolStripMenuItem, Me.EntryDataMahasiswaToolStripMenuItem, Me.PercabanganIfToolStripMenuItem})
        Me.Pertemuan3ToolStripMenuItem.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pertemuan3ToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer))
        Me.Pertemuan3ToolStripMenuItem.Name = "Pertemuan3ToolStripMenuItem"
        Me.Pertemuan3ToolStripMenuItem.Size = New System.Drawing.Size(119, 46)
        Me.Pertemuan3ToolStripMenuItem.Text = "Pertemuan 3"
        '
        'IfThenToolStripMenuItem
        '
        Me.IfThenToolStripMenuItem.Name = "IfThenToolStripMenuItem"
        Me.IfThenToolStripMenuItem.Size = New System.Drawing.Size(315, 28)
        Me.IfThenToolStripMenuItem.Text = "If--Then"
        '
        'IfThenElseToolStripMenuItem
        '
        Me.IfThenElseToolStripMenuItem.Name = "IfThenElseToolStripMenuItem"
        Me.IfThenElseToolStripMenuItem.Size = New System.Drawing.Size(315, 28)
        Me.IfThenElseToolStripMenuItem.Text = "If--Then--Else"
        '
        'IfElseIfEndIfCheckboxToolStripMenuItem
        '
        Me.IfElseIfEndIfCheckboxToolStripMenuItem.Name = "IfElseIfEndIfCheckboxToolStripMenuItem"
        Me.IfElseIfEndIfCheckboxToolStripMenuItem.Size = New System.Drawing.Size(315, 28)
        Me.IfElseIfEndIfCheckboxToolStripMenuItem.Text = "If--ElseIf--End If (Checkbox)"
        '
        'IfElseIfEndIfRadiobuttonToolStripMenuItem
        '
        Me.IfElseIfEndIfRadiobuttonToolStripMenuItem.Name = "IfElseIfEndIfRadiobuttonToolStripMenuItem"
        Me.IfElseIfEndIfRadiobuttonToolStripMenuItem.Size = New System.Drawing.Size(315, 28)
        Me.IfElseIfEndIfRadiobuttonToolStripMenuItem.Text = "If--ElseIf--End If (Radiobutton)"
        '
        'IfElseIfEndIfComboboxToolStripMenuItem
        '
        Me.IfElseIfEndIfComboboxToolStripMenuItem.Name = "IfElseIfEndIfComboboxToolStripMenuItem"
        Me.IfElseIfEndIfComboboxToolStripMenuItem.Size = New System.Drawing.Size(315, 28)
        Me.IfElseIfEndIfComboboxToolStripMenuItem.Text = "If--ElseIf--End If (Combobox)"
        '
        'NestedIfToolStripMenuItem
        '
        Me.NestedIfToolStripMenuItem.Name = "NestedIfToolStripMenuItem"
        Me.NestedIfToolStripMenuItem.Size = New System.Drawing.Size(315, 28)
        Me.NestedIfToolStripMenuItem.Text = "Nested If"
        '
        'EntryDataMahasiswaToolStripMenuItem
        '
        Me.EntryDataMahasiswaToolStripMenuItem.Name = "EntryDataMahasiswaToolStripMenuItem"
        Me.EntryDataMahasiswaToolStripMenuItem.Size = New System.Drawing.Size(315, 28)
        Me.EntryDataMahasiswaToolStripMenuItem.Text = "Entry Data Mahasiswa"
        '
        'PercabanganIfToolStripMenuItem
        '
        Me.PercabanganIfToolStripMenuItem.Name = "PercabanganIfToolStripMenuItem"
        Me.PercabanganIfToolStripMenuItem.Size = New System.Drawing.Size(315, 28)
        Me.PercabanganIfToolStripMenuItem.Text = "Percabangan If"
        '
        'Pertemuan4ToolStripMenuItem
        '
        Me.Pertemuan4ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SelectCaseListBoxToolStripMenuItem, Me.SelectCasePaketMakananToolStripMenuItem, Me.SelectCaseJurusanToolStripMenuItem, Me.SelectCaseNilaiToolStripMenuItem, Me.PerhitunganNilaiAkhirDanPenentuanGradeToolStripMenuItem, Me.PerhitunganGajiKaryawanToolStripMenuItem, Me.ProgramSPBUToolStripMenuItem})
        Me.Pertemuan4ToolStripMenuItem.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pertemuan4ToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer))
        Me.Pertemuan4ToolStripMenuItem.Name = "Pertemuan4ToolStripMenuItem"
        Me.Pertemuan4ToolStripMenuItem.Size = New System.Drawing.Size(119, 46)
        Me.Pertemuan4ToolStripMenuItem.Text = "Pertemuan 4"
        '
        'SelectCaseListBoxToolStripMenuItem
        '
        Me.SelectCaseListBoxToolStripMenuItem.Name = "SelectCaseListBoxToolStripMenuItem"
        Me.SelectCaseListBoxToolStripMenuItem.Size = New System.Drawing.Size(436, 28)
        Me.SelectCaseListBoxToolStripMenuItem.Text = "Select Case -- List Box"
        '
        'SelectCasePaketMakananToolStripMenuItem
        '
        Me.SelectCasePaketMakananToolStripMenuItem.Name = "SelectCasePaketMakananToolStripMenuItem"
        Me.SelectCasePaketMakananToolStripMenuItem.Size = New System.Drawing.Size(436, 28)
        Me.SelectCasePaketMakananToolStripMenuItem.Text = "Select Case -- Paket Makanan"
        '
        'SelectCaseJurusanToolStripMenuItem
        '
        Me.SelectCaseJurusanToolStripMenuItem.Name = "SelectCaseJurusanToolStripMenuItem"
        Me.SelectCaseJurusanToolStripMenuItem.Size = New System.Drawing.Size(436, 28)
        Me.SelectCaseJurusanToolStripMenuItem.Text = "Select Case -- Jurusan"
        '
        'SelectCaseNilaiToolStripMenuItem
        '
        Me.SelectCaseNilaiToolStripMenuItem.Name = "SelectCaseNilaiToolStripMenuItem"
        Me.SelectCaseNilaiToolStripMenuItem.Size = New System.Drawing.Size(436, 28)
        Me.SelectCaseNilaiToolStripMenuItem.Text = "Select Case -- Nilai"
        '
        'PerhitunganNilaiAkhirDanPenentuanGradeToolStripMenuItem
        '
        Me.PerhitunganNilaiAkhirDanPenentuanGradeToolStripMenuItem.Name = "PerhitunganNilaiAkhirDanPenentuanGradeToolStripMenuItem"
        Me.PerhitunganNilaiAkhirDanPenentuanGradeToolStripMenuItem.Size = New System.Drawing.Size(436, 28)
        Me.PerhitunganNilaiAkhirDanPenentuanGradeToolStripMenuItem.Text = "Perhitungan Nilai Akhir dan Penentuan Grade"
        '
        'PerhitunganGajiKaryawanToolStripMenuItem
        '
        Me.PerhitunganGajiKaryawanToolStripMenuItem.Name = "PerhitunganGajiKaryawanToolStripMenuItem"
        Me.PerhitunganGajiKaryawanToolStripMenuItem.Size = New System.Drawing.Size(436, 28)
        Me.PerhitunganGajiKaryawanToolStripMenuItem.Text = "Perhitungan Gaji Karyawan"
        '
        'ProgramSPBUToolStripMenuItem
        '
        Me.ProgramSPBUToolStripMenuItem.Name = "ProgramSPBUToolStripMenuItem"
        Me.ProgramSPBUToolStripMenuItem.Size = New System.Drawing.Size(436, 28)
        Me.ProgramSPBUToolStripMenuItem.Text = "Program SPBU"
        '
        'PertemuanToolStripMenuItem
        '
        Me.PertemuanToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PerulanganForNextToolStripMenuItem, Me.PerulanganForNextStepToolStripMenuItem, Me.PerulanganForNextDateToolStripMenuItem, Me.PerulanganForNextInputToolStripMenuItem, Me.PerulanganDoWhileLoopToolStripMenuItem, Me.PerulanganDoUntilLoopToolStripMenuItem, Me.PerulanganWhileEndWhileToolStripMenuItem, Me.PracticeLatihan1ToolStripMenuItem})
        Me.PertemuanToolStripMenuItem.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PertemuanToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer))
        Me.PertemuanToolStripMenuItem.Name = "PertemuanToolStripMenuItem"
        Me.PertemuanToolStripMenuItem.Size = New System.Drawing.Size(119, 46)
        Me.PertemuanToolStripMenuItem.Text = "Pertemuan 5"
        '
        'PerulanganForNextToolStripMenuItem
        '
        Me.PerulanganForNextToolStripMenuItem.Name = "PerulanganForNextToolStripMenuItem"
        Me.PerulanganForNextToolStripMenuItem.Size = New System.Drawing.Size(316, 28)
        Me.PerulanganForNextToolStripMenuItem.Text = "Perulangan For-Next"
        '
        'PerulanganForNextStepToolStripMenuItem
        '
        Me.PerulanganForNextStepToolStripMenuItem.Name = "PerulanganForNextStepToolStripMenuItem"
        Me.PerulanganForNextStepToolStripMenuItem.Size = New System.Drawing.Size(316, 28)
        Me.PerulanganForNextStepToolStripMenuItem.Text = "Perulangan For-Next (Step)"
        '
        'PerulanganForNextDateToolStripMenuItem
        '
        Me.PerulanganForNextDateToolStripMenuItem.Name = "PerulanganForNextDateToolStripMenuItem"
        Me.PerulanganForNextDateToolStripMenuItem.Size = New System.Drawing.Size(316, 28)
        Me.PerulanganForNextDateToolStripMenuItem.Text = "Perulangan For-Next (Date)"
        '
        'PerulanganForNextInputToolStripMenuItem
        '
        Me.PerulanganForNextInputToolStripMenuItem.Name = "PerulanganForNextInputToolStripMenuItem"
        Me.PerulanganForNextInputToolStripMenuItem.Size = New System.Drawing.Size(316, 28)
        Me.PerulanganForNextInputToolStripMenuItem.Text = "Perulangan For-Next (Input)"
        '
        'PerulanganDoWhileLoopToolStripMenuItem
        '
        Me.PerulanganDoWhileLoopToolStripMenuItem.Name = "PerulanganDoWhileLoopToolStripMenuItem"
        Me.PerulanganDoWhileLoopToolStripMenuItem.Size = New System.Drawing.Size(316, 28)
        Me.PerulanganDoWhileLoopToolStripMenuItem.Text = "Perulangan Do While - Loop"
        '
        'PerulanganDoUntilLoopToolStripMenuItem
        '
        Me.PerulanganDoUntilLoopToolStripMenuItem.Name = "PerulanganDoUntilLoopToolStripMenuItem"
        Me.PerulanganDoUntilLoopToolStripMenuItem.Size = New System.Drawing.Size(316, 28)
        Me.PerulanganDoUntilLoopToolStripMenuItem.Text = "Perulangan Do Until - Loop"
        '
        'PerulanganWhileEndWhileToolStripMenuItem
        '
        Me.PerulanganWhileEndWhileToolStripMenuItem.Name = "PerulanganWhileEndWhileToolStripMenuItem"
        Me.PerulanganWhileEndWhileToolStripMenuItem.Size = New System.Drawing.Size(316, 28)
        Me.PerulanganWhileEndWhileToolStripMenuItem.Text = "Perulangan While - End While"
        '
        'PracticeLatihan1ToolStripMenuItem
        '
        Me.PracticeLatihan1ToolStripMenuItem.Name = "PracticeLatihan1ToolStripMenuItem"
        Me.PracticeLatihan1ToolStripMenuItem.Size = New System.Drawing.Size(316, 28)
        Me.PracticeLatihan1ToolStripMenuItem.Text = "Practice Latihan 1"
        '
        'Pertemuan6ToolStripMenuItem
        '
        Me.Pertemuan6ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.IndexArrayComboBoxToolStripMenuItem, Me.BulanIndexToolStripMenuItem, Me.MaskapaiPenerbanganToolStripMenuItem, Me.PracticeOfArray01ToolStripMenuItem, Me.TampilanDataToolStripMenuItem, Me.PracticeOfArray02ToolStripMenuItem})
        Me.Pertemuan6ToolStripMenuItem.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pertemuan6ToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer))
        Me.Pertemuan6ToolStripMenuItem.Name = "Pertemuan6ToolStripMenuItem"
        Me.Pertemuan6ToolStripMenuItem.Size = New System.Drawing.Size(119, 46)
        Me.Pertemuan6ToolStripMenuItem.Text = "Pertemuan 6"
        '
        'IndexArrayComboBoxToolStripMenuItem
        '
        Me.IndexArrayComboBoxToolStripMenuItem.Name = "IndexArrayComboBoxToolStripMenuItem"
        Me.IndexArrayComboBoxToolStripMenuItem.Size = New System.Drawing.Size(284, 28)
        Me.IndexArrayComboBoxToolStripMenuItem.Text = "Index Array (Combo Box)"
        '
        'BulanIndexToolStripMenuItem
        '
        Me.BulanIndexToolStripMenuItem.Name = "BulanIndexToolStripMenuItem"
        Me.BulanIndexToolStripMenuItem.Size = New System.Drawing.Size(284, 28)
        Me.BulanIndexToolStripMenuItem.Text = "Bulan Index"
        '
        'MaskapaiPenerbanganToolStripMenuItem
        '
        Me.MaskapaiPenerbanganToolStripMenuItem.Name = "MaskapaiPenerbanganToolStripMenuItem"
        Me.MaskapaiPenerbanganToolStripMenuItem.Size = New System.Drawing.Size(284, 28)
        Me.MaskapaiPenerbanganToolStripMenuItem.Text = "Maskapai Penerbangan"
        '
        'PracticeOfArray01ToolStripMenuItem
        '
        Me.PracticeOfArray01ToolStripMenuItem.Name = "PracticeOfArray01ToolStripMenuItem"
        Me.PracticeOfArray01ToolStripMenuItem.Size = New System.Drawing.Size(284, 28)
        Me.PracticeOfArray01ToolStripMenuItem.Text = "Practice of Array 01"
        '
        'TampilanDataToolStripMenuItem
        '
        Me.TampilanDataToolStripMenuItem.Name = "TampilanDataToolStripMenuItem"
        Me.TampilanDataToolStripMenuItem.Size = New System.Drawing.Size(284, 28)
        Me.TampilanDataToolStripMenuItem.Text = "Tampilan Data"
        '
        'PracticeOfArray02ToolStripMenuItem
        '
        Me.PracticeOfArray02ToolStripMenuItem.Name = "PracticeOfArray02ToolStripMenuItem"
        Me.PracticeOfArray02ToolStripMenuItem.Size = New System.Drawing.Size(284, 28)
        Me.PracticeOfArray02ToolStripMenuItem.Text = "Practice of Array 02"
        '
        'Pertemuan8ToolStripMenuItem
        '
        Me.Pertemuan8ToolStripMenuItem.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pertemuan8ToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer))
        Me.Pertemuan8ToolStripMenuItem.Name = "Pertemuan8ToolStripMenuItem"
        Me.Pertemuan8ToolStripMenuItem.Size = New System.Drawing.Size(119, 46)
        Me.Pertemuan8ToolStripMenuItem.Text = "Pertemuan 8"
        '
        'Pretemuan9ToolStripMenuItem
        '
        Me.Pretemuan9ToolStripMenuItem.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pretemuan9ToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer))
        Me.Pretemuan9ToolStripMenuItem.Name = "Pretemuan9ToolStripMenuItem"
        Me.Pretemuan9ToolStripMenuItem.Size = New System.Drawing.Size(119, 46)
        Me.Pretemuan9ToolStripMenuItem.Text = "Pertemuan 9"
        '
        'Pertemuan10ToolStripMenuItem
        '
        Me.Pertemuan10ToolStripMenuItem.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pertemuan10ToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer))
        Me.Pertemuan10ToolStripMenuItem.Name = "Pertemuan10ToolStripMenuItem"
        Me.Pertemuan10ToolStripMenuItem.Size = New System.Drawing.Size(128, 46)
        Me.Pertemuan10ToolStripMenuItem.Text = "Pertemuan 10"
        '
        'Pertemuan11ToolStripMenuItem
        '
        Me.Pertemuan11ToolStripMenuItem.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pertemuan11ToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer))
        Me.Pertemuan11ToolStripMenuItem.Name = "Pertemuan11ToolStripMenuItem"
        Me.Pertemuan11ToolStripMenuItem.Size = New System.Drawing.Size(128, 46)
        Me.Pertemuan11ToolStripMenuItem.Text = "Pertemuan 11"
        '
        'Pertemuan12ToolStripMenuItem
        '
        Me.Pertemuan12ToolStripMenuItem.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pertemuan12ToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer))
        Me.Pertemuan12ToolStripMenuItem.Name = "Pertemuan12ToolStripMenuItem"
        Me.Pertemuan12ToolStripMenuItem.Size = New System.Drawing.Size(128, 46)
        Me.Pertemuan12ToolStripMenuItem.Text = "Pertemuan 12"
        '
        'Pertemuan13ToolStripMenuItem
        '
        Me.Pertemuan13ToolStripMenuItem.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pertemuan13ToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer))
        Me.Pertemuan13ToolStripMenuItem.Name = "Pertemuan13ToolStripMenuItem"
        Me.Pertemuan13ToolStripMenuItem.Size = New System.Drawing.Size(128, 46)
        Me.Pertemuan13ToolStripMenuItem.Text = "Pertemuan 13"
        '
        'Pertemuan14ToolStripMenuItem
        '
        Me.Pertemuan14ToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer))
        Me.Pertemuan14ToolStripMenuItem.Name = "Pertemuan14ToolStripMenuItem"
        Me.Pertemuan14ToolStripMenuItem.Size = New System.Drawing.Size(160, 46)
        Me.Pertemuan14ToolStripMenuItem.Text = "Pertemuan 14"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(117, Byte), Integer), CType(CType(117, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(25, 273)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(290, 54)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "MAIN MENU"
        '
        'StatusStrip1
        '
        Me.StatusStrip1.BackColor = System.Drawing.Color.FromArgb(CType(CType(57, Byte), Integer), CType(CType(61, Byte), Integer), CType(CType(75, Byte), Integer))
        Me.StatusStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel2})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 815)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Padding = New System.Windows.Forms.Padding(1, 0, 19, 0)
        Me.StatusStrip1.Size = New System.Drawing.Size(1604, 26)
        Me.StatusStrip1.TabIndex = 3
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripStatusLabel2
        '
        Me.ToolStripStatusLabel2.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Italic)
        Me.ToolStripStatusLabel2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.ToolStripStatusLabel2.Name = "ToolStripStatusLabel2"
        Me.ToolStripStatusLabel2.Size = New System.Drawing.Size(686, 20)
        Me.ToolStripStatusLabel2.Text = "Univeristas Putera Batam | Sistem Informasi | Tahun 2020 | Dosen: Saut Pintubipar" &
    " Saragih, S.Kom., M.MSI."
        '
        'StatusStrip2
        '
        Me.StatusStrip2.BackColor = System.Drawing.Color.FromArgb(CType(CType(57, Byte), Integer), CType(CType(61, Byte), Integer), CType(CType(75, Byte), Integer))
        Me.StatusStrip2.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.StatusStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel3})
        Me.StatusStrip2.Location = New System.Drawing.Point(0, 789)
        Me.StatusStrip2.Name = "StatusStrip2"
        Me.StatusStrip2.Padding = New System.Windows.Forms.Padding(1, 0, 19, 0)
        Me.StatusStrip2.Size = New System.Drawing.Size(1604, 26)
        Me.StatusStrip2.TabIndex = 4
        Me.StatusStrip2.Text = "StatusStrip2"
        '
        'ToolStripStatusLabel3
        '
        Me.ToolStripStatusLabel3.Font = New System.Drawing.Font("Segoe UI", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle))
        Me.ToolStripStatusLabel3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.ToolStripStatusLabel3.Name = "ToolStripStatusLabel3"
        Me.ToolStripStatusLabel3.Size = New System.Drawing.Size(832, 20)
        Me.ToolStripStatusLabel3.Text = "Created by Ayu Wulandari, Hikmatunisa. Nirpan Sepentia, Silvi Novebri, Soli Verni" &
    "ka Manalu, Vilona Fitri Alfionita"
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.PictureBox1)
        Me.Panel1.Location = New System.Drawing.Point(0, 38)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(4)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(368, 842)
        Me.Panel1.TabIndex = 6
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(35, 43)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(4)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(284, 210)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 2
        Me.PictureBox1.TabStop = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1604, 841)
        Me.Controls.Add(Me.StatusStrip2)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.Panel1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.IsMdiContainer = True
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "MAIN MENU"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.StatusStrip2.ResumeLayout(False)
        Me.StatusStrip2.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents Pertemuan1ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Pertemuan2ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Pertemuan3ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Pertemuan4ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PertemuanToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Pertemuan6ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Pertemuan8ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Pretemuan9ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Pertemuan10ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Label1 As Label
    Friend WithEvents HelloWorldToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MessageBoxToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents StatusStrip1 As StatusStrip
    Friend WithEvents ToolStripStatusLabel2 As ToolStripStatusLabel
    Friend WithEvents Pertemuan11ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Pertemuan12ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Pertemuan13ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Pertemuan14ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents StatusStrip2 As StatusStrip
    Friend WithEvents ToolStripStatusLabel3 As ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel4 As ToolStripStatusLabel
    Friend WithEvents Panel1 As Panel
    Friend WithEvents OperatorRelasiToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ChangeKursToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents OperatorPerhitungan1ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents OperatorPerhitungan2ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ConvertTipeDataToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PembayaranToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents IfThenToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents IfThenElseToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SelectCaseListBoxToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SelectCasePaketMakananToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SelectCaseJurusanToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SelectCaseNilaiToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PerhitunganNilaiAkhirDanPenentuanGradeToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PerhitunganGajiKaryawanToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ProgramSPBUToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents IfElseIfEndIfCheckboxToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents IfElseIfEndIfRadiobuttonToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents IfElseIfEndIfComboboxToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents NestedIfToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents EntryDataMahasiswaToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PercabanganIfToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PerulanganForNextToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PerulanganForNextStepToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PerulanganForNextDateToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PerulanganForNextInputToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PerulanganDoWhileLoopToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PerulanganDoUntilLoopToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PerulanganWhileEndWhileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PracticeLatihan1ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents IndexArrayComboBoxToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BulanIndexToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MaskapaiPenerbanganToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PracticeOfArray01ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TampilanDataToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PracticeOfArray02ToolStripMenuItem As ToolStripMenuItem
End Class
