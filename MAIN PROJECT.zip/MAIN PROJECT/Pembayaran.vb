﻿Public Class Pembayaran
    Private Sub btnBayar_Click(sender As Object, e As EventArgs) Handles btnBayar.Click
        tSisa.Text = Val(tBayar.Text) - Val(tTotal.Text)
    End Sub


    Private Sub tQty_TextChanged(sender As Object, e As EventArgs) Handles tQty.TextChanged
        Dim total As Double

        total = Val(tHarga.Text) * Val(tQty.Text)


        tDiscount.Text = total * 5 / 100
        tPajak.Text = total * 2 / 100

    End Sub

    Private Sub btnHitung_Click(sender As Object, e As EventArgs) Handles btnHitung.Click
        Dim harga, pajak, diskon As Double
        Dim qty As Integer

        harga = Val(tHarga.Text)
        pajak = Val(tPajak.Text)
        diskon = Val(tDiscount.Text)
        qty = Val(tQty.Text)

        tTotal.Text = (harga * qty) - diskon - pajak
    End Sub

    Private Sub Pembayaran_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        tNama.Select()
    End Sub
End Class