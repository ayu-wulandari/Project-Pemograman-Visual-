﻿Public Class Percabangan_If
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()

    End Sub

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim a, b, c, d, total As Double

        a = Val(t10.Text)
        b = Val(t20.Text)
        c = Val(t30.Text)
        d = Val(t40.Text)


        total = a + b + c + d

        tTotal.Text = total

        If total <= 56 Then
            tGrade.Text = "E"
            tKet.Text = "Nilai Anda Sangat Kurang. Maaf, Anda Tidak Lulus"
        ElseIf total <= 65 Then
            tGrade.Text = "D"
            tKet.Text = "Nilai Anda Kurang. Maaf, Anda Tidak Lulus"
        ElseIf total <= 75 Then
            tGrade.Text = "C"
            tKet.Text = "Nilai Anda Cukup. Anda Lulus, Tingkatkan Lagi Semangat Belajarmu!"
        ElseIf total <= 85 Then
            tGrade.Text = "B"
            tKet.Text = "Nilai Anda Baik. Anda Lulus, Pertahankan!"
        ElseIf total > 85 Then
            tGrade.Text = "A"
            tKet.Text = "Nilai Anda Sangat Baik! Anda Lulus, Selamat!"
        End If



    End Sub

    Private Sub tAbsen_TextChanged(sender As Object, e As EventArgs) Handles tAbsen.TextChanged
        Dim absen As Double
        absen = Val(tAbsen.Text)

        t10.Text = absen * 10 / 100

    End Sub

    Private Sub tTugas_TextChanged(sender As Object, e As EventArgs) Handles tTugas.TextChanged
        Dim tugas As Double
        tugas = Val(tTugas.Text)

        t20.Text = tugas * 20 / 100
    End Sub

    Private Sub tUTS_TextChanged(sender As Object, e As EventArgs) Handles tUTS.TextChanged
        Dim UTS As Double
        UTS = Val(tUTS.Text)

        t30.Text = UTS * 30 / 100
    End Sub

    Private Sub tUAS_TextChanged(sender As Object, e As EventArgs) Handles tUAS.TextChanged
        Dim UAS As Double
        UAS = Val(tUAS.Text)

        t40.Text = UAS * 40 / 100
    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        tAbsen.Text = ""
        tTugas.Text = ""
        tUTS.Text = ""
        tUAS.Text = ""
        t10.Text = ""
        t20.Text = ""
        t30.Text = ""
        t40.Text = ""
        tTotal.Text = ""
        tGrade.Text = ""
        tKet.Text = ""
        tAbsen.Focus()

    End Sub
End Class