﻿Public Class Form2
    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ComboBox1.Items.Add("Paket1")
        ComboBox1.Items.Add("Paket2")
        ComboBox1.Items.Add("Paket3")
        ComboBox1.Items.Add("Paket4")
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged
        If ComboBox1.Text = "Paket 1" Then
            GroupBox1.Text = ComboBox1.Text
            Me.TextBox1.Text = "Rendang"
            Me.TextBox2.Text = "Teh Manis"
            Me.TextBox3.Text = "110000"
        ElseIf ComboBox1.Text = "Paket 2" Then
            GroupBox1.Text = ComboBox1.Text
            Me.TextBox1.Text = "Ayam Goreng"
            Me.TextBox2.Text = "Teh Tarik"
            Me.TextBox3.Text = "150000"
        ElseIf ComboBox1.Text = "Paket 3" Then
            GroupBox1.Text = ComboBox1.Text
            Me.TextBox1.Text = "Ayam Bakar"
            Me.TextBox2.Text = "Es Teh"
            Me.TextBox3.Text = "165000"
        Else
            GroupBox1.Text = ComboBox1.Text
            Me.TextBox1.Text = "Nasi Bakar"
            Me.TextBox2.Text = "Es Jeruk"
            Me.TextBox3.Text = "155000"
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub
End Class