﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Nested_IF
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Texket = New System.Windows.Forms.TextBox()
        Me.Cmdproses = New System.Windows.Forms.Button()
        Me.cmbstatus = New System.Windows.Forms.ComboBox()
        Me.RBW = New System.Windows.Forms.RadioButton()
        Me.RBP = New System.Windows.Forms.RadioButton()
        Me.LabelKeterangan = New System.Windows.Forms.Label()
        Me.LabelStatus = New System.Windows.Forms.Label()
        Me.LabelGender = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Texket
        '
        Me.Texket.Enabled = False
        Me.Texket.Location = New System.Drawing.Point(223, 258)
        Me.Texket.Margin = New System.Windows.Forms.Padding(2)
        Me.Texket.Name = "Texket"
        Me.Texket.Size = New System.Drawing.Size(76, 22)
        Me.Texket.TabIndex = 15
        '
        'Cmdproses
        '
        Me.Cmdproses.Location = New System.Drawing.Point(224, 184)
        Me.Cmdproses.Margin = New System.Windows.Forms.Padding(2)
        Me.Cmdproses.Name = "Cmdproses"
        Me.Cmdproses.Size = New System.Drawing.Size(109, 29)
        Me.Cmdproses.TabIndex = 14
        Me.Cmdproses.Text = "Proses"
        Me.Cmdproses.UseVisualStyleBackColor = True
        '
        'cmbstatus
        '
        Me.cmbstatus.FormattingEnabled = True
        Me.cmbstatus.Location = New System.Drawing.Point(224, 128)
        Me.cmbstatus.Margin = New System.Windows.Forms.Padding(2)
        Me.cmbstatus.Name = "cmbstatus"
        Me.cmbstatus.Size = New System.Drawing.Size(92, 24)
        Me.cmbstatus.TabIndex = 13
        '
        'RBW
        '
        Me.RBW.AutoSize = True
        Me.RBW.Location = New System.Drawing.Point(288, 84)
        Me.RBW.Margin = New System.Windows.Forms.Padding(2)
        Me.RBW.Name = "RBW"
        Me.RBW.Size = New System.Drawing.Size(73, 21)
        Me.RBW.TabIndex = 12
        Me.RBW.TabStop = True
        Me.RBW.Text = "Wanita"
        Me.RBW.UseVisualStyleBackColor = True
        '
        'RBP
        '
        Me.RBP.AutoSize = True
        Me.RBP.Location = New System.Drawing.Point(224, 85)
        Me.RBP.Margin = New System.Windows.Forms.Padding(2)
        Me.RBP.Name = "RBP"
        Me.RBP.Size = New System.Drawing.Size(54, 21)
        Me.RBP.TabIndex = 11
        Me.RBP.TabStop = True
        Me.RBP.Text = "Pria"
        Me.RBP.UseVisualStyleBackColor = True
        '
        'LabelKeterangan
        '
        Me.LabelKeterangan.AutoSize = True
        Me.LabelKeterangan.Location = New System.Drawing.Point(50, 258)
        Me.LabelKeterangan.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LabelKeterangan.Name = "LabelKeterangan"
        Me.LabelKeterangan.Size = New System.Drawing.Size(82, 17)
        Me.LabelKeterangan.TabIndex = 10
        Me.LabelKeterangan.Text = "Keterangan"
        '
        'LabelStatus
        '
        Me.LabelStatus.AutoSize = True
        Me.LabelStatus.Location = New System.Drawing.Point(50, 134)
        Me.LabelStatus.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LabelStatus.Name = "LabelStatus"
        Me.LabelStatus.Size = New System.Drawing.Size(48, 17)
        Me.LabelStatus.TabIndex = 9
        Me.LabelStatus.Text = "Status"
        '
        'LabelGender
        '
        Me.LabelGender.AutoSize = True
        Me.LabelGender.Location = New System.Drawing.Point(50, 85)
        Me.LabelGender.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LabelGender.Name = "LabelGender"
        Me.LabelGender.Size = New System.Drawing.Size(56, 17)
        Me.LabelGender.TabIndex = 8
        Me.LabelGender.Text = "Gender"
        '
        'Nested_IF
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(538, 354)
        Me.Controls.Add(Me.Texket)
        Me.Controls.Add(Me.Cmdproses)
        Me.Controls.Add(Me.cmbstatus)
        Me.Controls.Add(Me.RBW)
        Me.Controls.Add(Me.RBP)
        Me.Controls.Add(Me.LabelKeterangan)
        Me.Controls.Add(Me.LabelStatus)
        Me.Controls.Add(Me.LabelGender)
        Me.Name = "Nested_IF"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Nested_IF"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Texket As TextBox
    Friend WithEvents Cmdproses As Button
    Friend WithEvents cmbstatus As ComboBox
    Friend WithEvents RBW As RadioButton
    Friend WithEvents RBP As RadioButton
    Friend WithEvents LabelKeterangan As Label
    Friend WithEvents LabelStatus As Label
    Friend WithEvents LabelGender As Label
End Class
