﻿Public Class Select_Case_Paket_Makanan
    Private Sub Select_Case_Paket_Makanan_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ComboBox1.Items.Clear()
        ComboBox1.Items.Add("Paket 1")
        ComboBox1.Items.Add("Paket 2")
        ComboBox1.Items.Add("Paket 3")
        ComboBox1.Items.Add("Paket 4")
        ComboBox1.Items.Add("Paket 5")
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged
        Select Case (Me.ComboBox1.Text)
            Case ("Paket 1")
                Me.EMakanan.Text = "Rendang"
                Me.EMinuman.Text = "Teh Obeng"
                Me.EHarga.Text = "25000"
            Case ("Paket 2")
                Me.EMakanan.Text = "Pempek Komplit"
                Me.EMinuman.Text = "Ice Jeruk"
                Me.EHarga.Text = "26000"
            Case ("Paket 3")
                Me.EMakanan.Text = "Ayam Penyet"
                Me.EMinuman.Text = "Teh O"
                Me.EHarga.Text = "28000"
            Case ("Paket 4")
                Me.EMakanan.Text = "Ayam Bakar"
                Me.EMinuman.Text = "Air Mineral"
                Me.EHarga.Text = "22000"
            Case Else
                Me.EMakanan.Text = "Ikan Bakar"
                Me.EMinuman.Text = "Es Kosong"
                Me.EHarga.Text = "23000"
        End Select

    End Sub
End Class