﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class perhitungan_nilai_akhir_dan_penentuan_G
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TxtNgrade = New System.Windows.Forms.TextBox()
        Me.TxtNA = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.bproses = New System.Windows.Forms.Button()
        Me.TxtNuas = New System.Windows.Forms.TextBox()
        Me.TxtNuts = New System.Windows.Forms.TextBox()
        Me.TxtNtgs = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'TxtNgrade
        '
        Me.TxtNgrade.Location = New System.Drawing.Point(164, 364)
        Me.TxtNgrade.Name = "TxtNgrade"
        Me.TxtNgrade.Size = New System.Drawing.Size(100, 20)
        Me.TxtNgrade.TabIndex = 25
        '
        'TxtNA
        '
        Me.TxtNA.Location = New System.Drawing.Point(164, 322)
        Me.TxtNA.Name = "TxtNA"
        Me.TxtNA.Size = New System.Drawing.Size(100, 20)
        Me.TxtNA.TabIndex = 24
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(44, 364)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(34, 13)
        Me.Label7.TabIndex = 23
        Me.Label7.Text = "grade"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(44, 322)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(51, 13)
        Me.Label6.TabIndex = 22
        Me.Label6.Text = "nilai akhir"
        '
        'bproses
        '
        Me.bproses.Location = New System.Drawing.Point(107, 267)
        Me.bproses.Name = "bproses"
        Me.bproses.Size = New System.Drawing.Size(98, 23)
        Me.bproses.TabIndex = 21
        Me.bproses.Text = "proses"
        Me.bproses.UseVisualStyleBackColor = True
        '
        'TxtNuas
        '
        Me.TxtNuas.Location = New System.Drawing.Point(164, 217)
        Me.TxtNuas.Name = "TxtNuas"
        Me.TxtNuas.Size = New System.Drawing.Size(100, 20)
        Me.TxtNuas.TabIndex = 20
        '
        'TxtNuts
        '
        Me.TxtNuts.Location = New System.Drawing.Point(164, 179)
        Me.TxtNuts.Name = "TxtNuts"
        Me.TxtNuts.Size = New System.Drawing.Size(100, 20)
        Me.TxtNuts.TabIndex = 19
        '
        'TxtNtgs
        '
        Me.TxtNtgs.Location = New System.Drawing.Point(164, 144)
        Me.TxtNtgs.Name = "TxtNtgs"
        Me.TxtNtgs.Size = New System.Drawing.Size(100, 20)
        Me.TxtNtgs.TabIndex = 18
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(44, 217)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(45, 13)
        Me.Label5.TabIndex = 17
        Me.Label5.Text = "nilai uas"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(44, 179)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(42, 13)
        Me.Label4.TabIndex = 16
        Me.Label4.Text = "nilai uts"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(44, 144)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(54, 13)
        Me.Label3.TabIndex = 15
        Me.Label3.Text = "nilai tugas"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(101, 94)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(270, 31)
        Me.Label2.TabIndex = 14
        Me.Label2.Text = "dan penentuan grade"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(90, 63)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(306, 31)
        Me.Label1.TabIndex = 13
        Me.Label1.Text = "penghitungan nilai akhir "
        '
        'perhitungan_nilai_akhir_dan_penentuan_G
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(441, 447)
        Me.Controls.Add(Me.TxtNgrade)
        Me.Controls.Add(Me.TxtNA)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.bproses)
        Me.Controls.Add(Me.TxtNuas)
        Me.Controls.Add(Me.TxtNuts)
        Me.Controls.Add(Me.TxtNtgs)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "perhitungan_nilai_akhir_dan_penentuan_G"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "perhitungan_nilai_akhir_dan_penentuan_G"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents TxtNgrade As TextBox
    Friend WithEvents TxtNA As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents bproses As Button
    Friend WithEvents TxtNuas As TextBox
    Friend WithEvents TxtNuts As TextBox
    Friend WithEvents TxtNtgs As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
End Class
