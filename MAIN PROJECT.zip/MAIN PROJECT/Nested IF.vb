﻿Public Class Nested_IF
    Private Sub Cmdproses_Click(sender As Object, e As EventArgs) Handles Cmdproses.Click
        If RBP.Checked = True Then
            If cmbstatus.Text = "Menikah" Then
                Texket.Text = "Ayah"
            Else
                Texket.Text = "Jejaka"
            End If
        Else
            If cmbstatus.Text = "Menikah" Then
                Texket.Text = "Ibu"
            Else
                Texket.Text = "Gadis"
            End If

        End If
    End Sub

    Private Sub Nested_IF_Activated(sender As Object, e As EventArgs) Handles MyBase.Activated
        cmbstatus.Items.Clear()
        cmbstatus.Items.Add("Menikah")
        cmbstatus.Items.Add("Bujang")
    End Sub
End Class