﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class select_case
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.LblKet = New System.Windows.Forms.Label()
        Me.LblNilai = New System.Windows.Forms.Label()
        Me.TxtAngka = New System.Windows.Forms.TextBox()
        Me.Bclick = New System.Windows.Forms.Button()
        Me.masukannilai = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'LblKet
        '
        Me.LblKet.AutoSize = True
        Me.LblKet.Location = New System.Drawing.Point(180, 237)
        Me.LblKet.Name = "LblKet"
        Me.LblKet.Size = New System.Drawing.Size(22, 13)
        Me.LblKet.TabIndex = 9
        Me.LblKet.Text = "ket"
        '
        'LblNilai
        '
        Me.LblNilai.AutoSize = True
        Me.LblNilai.Location = New System.Drawing.Point(180, 203)
        Me.LblNilai.Name = "LblNilai"
        Me.LblNilai.Size = New System.Drawing.Size(34, 13)
        Me.LblNilai.TabIndex = 8
        Me.LblNilai.Text = "grade"
        '
        'TxtAngka
        '
        Me.TxtAngka.Location = New System.Drawing.Point(180, 83)
        Me.TxtAngka.Name = "TxtAngka"
        Me.TxtAngka.Size = New System.Drawing.Size(118, 20)
        Me.TxtAngka.TabIndex = 7
        '
        'Bclick
        '
        Me.Bclick.Location = New System.Drawing.Point(183, 161)
        Me.Bclick.Name = "Bclick"
        Me.Bclick.Size = New System.Drawing.Size(75, 23)
        Me.Bclick.TabIndex = 6
        Me.Bclick.Text = "click"
        Me.Bclick.UseVisualStyleBackColor = True
        '
        'masukannilai
        '
        Me.masukannilai.AutoSize = True
        Me.masukannilai.Location = New System.Drawing.Point(71, 86)
        Me.masukannilai.Name = "masukannilai"
        Me.masukannilai.Size = New System.Drawing.Size(71, 13)
        Me.masukannilai.TabIndex = 5
        Me.masukannilai.Text = "masukan nilai"
        '
        'select_case
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(369, 333)
        Me.Controls.Add(Me.LblKet)
        Me.Controls.Add(Me.LblNilai)
        Me.Controls.Add(Me.TxtAngka)
        Me.Controls.Add(Me.Bclick)
        Me.Controls.Add(Me.masukannilai)
        Me.Name = "select_case"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "select_case"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents LblKet As Label
    Friend WithEvents LblNilai As Label
    Friend WithEvents TxtAngka As TextBox
    Friend WithEvents Bclick As Button
    Friend WithEvents masukannilai As Label
End Class
