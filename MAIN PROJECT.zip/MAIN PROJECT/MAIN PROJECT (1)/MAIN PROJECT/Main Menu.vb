﻿Public Class Form1
    Private Sub HelloWorldToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HelloWorldToolStripMenuItem.Click

        Form_HelloWorld.MdiParent = Me
        Form_HelloWorld.Show()

    End Sub

    Private Sub MessageBoxToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MessageBoxToolStripMenuItem.Click

        Form_MessageBox.MdiParent = Me
        Form_MessageBox.Show()

    End Sub

    Private Sub OperatorRelasiToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OperatorRelasiToolStripMenuItem.Click
        program_operator_relasi.MdiParent = Me
        program_operator_relasi.Show()
    End Sub

    Private Sub OperatorPerhitungan1ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OperatorPerhitungan1ToolStripMenuItem.Click
        Operator_Perhitungan.MdiParent = Me
        Operator_Perhitungan.Show()
    End Sub
End Class
