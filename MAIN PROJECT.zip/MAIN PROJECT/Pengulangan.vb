﻿Public Class Pengulangan
    Private Sub Pengulangan_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim a As VariantType

        For a = 1 To 31
            Me.ComboBox1.Items.Add(Str(a))
        Next a

        For a = 1 To 12
            Me.ComboBox2.Items.Add(MonthName(a))
        Next a

        For a = 1945 To Year(Now)
            Me.ComboBox3.Items.Add(Str(a))
        Next a
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub
End Class