﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class selectcaseJurusan
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TxtKode = New System.Windows.Forms.TextBox()
        Me.LblJur = New System.Windows.Forms.Label()
        Me.LblProgram = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 24)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(69, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Kode jurusan"
        '
        'TxtKode
        '
        Me.TxtKode.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.TxtKode.Location = New System.Drawing.Point(107, 22)
        Me.TxtKode.Name = "TxtKode"
        Me.TxtKode.Size = New System.Drawing.Size(100, 20)
        Me.TxtKode.TabIndex = 1
        '
        'LblJur
        '
        Me.LblJur.AutoSize = True
        Me.LblJur.Location = New System.Drawing.Point(12, 66)
        Me.LblJur.Name = "LblJur"
        Me.LblJur.Size = New System.Drawing.Size(75, 13)
        Me.LblJur.TabIndex = 2
        Me.LblJur.Text = "Nama Jurusan"
        '
        'LblProgram
        '
        Me.LblProgram.AutoSize = True
        Me.LblProgram.Location = New System.Drawing.Point(12, 101)
        Me.LblProgram.Name = "LblProgram"
        Me.LblProgram.Size = New System.Drawing.Size(46, 13)
        Me.LblProgram.TabIndex = 3
        Me.LblProgram.Text = "Program"
        '
        'selectcaseJurusan
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.ClientSize = New System.Drawing.Size(254, 162)
        Me.Controls.Add(Me.LblProgram)
        Me.Controls.Add(Me.LblJur)
        Me.Controls.Add(Me.TxtKode)
        Me.Controls.Add(Me.Label1)
        Me.Name = "selectcaseJurusan"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Select Case jurusan"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents TxtKode As TextBox
    Friend WithEvents LblJur As Label
    Friend WithEvents LblProgram As Label
End Class
