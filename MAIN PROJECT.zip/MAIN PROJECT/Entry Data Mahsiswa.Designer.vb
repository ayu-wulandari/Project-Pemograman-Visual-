﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.RbtPerempuan = New System.Windows.Forms.RadioButton()
        Me.CmdProses = New System.Windows.Forms.Button()
        Me.RbtLaki = New System.Windows.Forms.RadioButton()
        Me.CmbJurusan = New System.Windows.Forms.ComboBox()
        Me.LJenis = New System.Windows.Forms.Label()
        Me.ENAMA = New System.Windows.Forms.TextBox()
        Me.LJurusan = New System.Windows.Forms.Label()
        Me.ENIM = New System.Windows.Forms.TextBox()
        Me.nama = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.RbtPerempuan)
        Me.GroupBox1.Controls.Add(Me.CmdProses)
        Me.GroupBox1.Controls.Add(Me.RbtLaki)
        Me.GroupBox1.Controls.Add(Me.CmbJurusan)
        Me.GroupBox1.Controls.Add(Me.LJenis)
        Me.GroupBox1.Controls.Add(Me.ENAMA)
        Me.GroupBox1.Controls.Add(Me.LJurusan)
        Me.GroupBox1.Controls.Add(Me.ENIM)
        Me.GroupBox1.Controls.Add(Me.nama)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(22, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(302, 305)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(17, 278)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(0, 13)
        Me.Label4.TabIndex = 6
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(17, 251)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(0, 13)
        Me.Label3.TabIndex = 5
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(17, 225)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(0, 13)
        Me.Label2.TabIndex = 4
        '
        'RbtPerempuan
        '
        Me.RbtPerempuan.AutoSize = True
        Me.RbtPerempuan.Font = New System.Drawing.Font("Microsoft YaHei", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RbtPerempuan.Location = New System.Drawing.Point(193, 126)
        Me.RbtPerempuan.Name = "RbtPerempuan"
        Me.RbtPerempuan.Size = New System.Drawing.Size(88, 20)
        Me.RbtPerempuan.TabIndex = 1
        Me.RbtPerempuan.TabStop = True
        Me.RbtPerempuan.Text = "Perempuan"
        Me.RbtPerempuan.UseVisualStyleBackColor = True
        '
        'CmdProses
        '
        Me.CmdProses.Font = New System.Drawing.Font("Microsoft YaHei", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdProses.Location = New System.Drawing.Point(106, 166)
        Me.CmdProses.Name = "CmdProses"
        Me.CmdProses.Size = New System.Drawing.Size(75, 29)
        Me.CmdProses.TabIndex = 3
        Me.CmdProses.Text = "PROSES"
        Me.CmdProses.UseVisualStyleBackColor = True
        '
        'RbtLaki
        '
        Me.RbtLaki.AutoSize = True
        Me.RbtLaki.Font = New System.Drawing.Font("Microsoft YaHei", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RbtLaki.Location = New System.Drawing.Point(106, 126)
        Me.RbtLaki.Name = "RbtLaki"
        Me.RbtLaki.Size = New System.Drawing.Size(81, 20)
        Me.RbtLaki.TabIndex = 1
        Me.RbtLaki.TabStop = True
        Me.RbtLaki.Text = "Laki - Laki"
        Me.RbtLaki.UseVisualStyleBackColor = True
        '
        'CmbJurusan
        '
        Me.CmbJurusan.FormattingEnabled = True
        Me.CmbJurusan.Location = New System.Drawing.Point(106, 90)
        Me.CmbJurusan.Name = "CmbJurusan"
        Me.CmbJurusan.Size = New System.Drawing.Size(175, 21)
        Me.CmbJurusan.TabIndex = 1
        '
        'LJenis
        '
        Me.LJenis.AutoSize = True
        Me.LJenis.Font = New System.Drawing.Font("Microsoft YaHei", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LJenis.Location = New System.Drawing.Point(6, 128)
        Me.LJenis.Name = "LJenis"
        Me.LJenis.Size = New System.Drawing.Size(81, 16)
        Me.LJenis.TabIndex = 1
        Me.LJenis.Text = "Jenis Kelamin"
        '
        'ENAMA
        '
        Me.ENAMA.Location = New System.Drawing.Point(106, 56)
        Me.ENAMA.Name = "ENAMA"
        Me.ENAMA.Size = New System.Drawing.Size(175, 20)
        Me.ENAMA.TabIndex = 2
        '
        'LJurusan
        '
        Me.LJurusan.AutoSize = True
        Me.LJurusan.Font = New System.Drawing.Font("Microsoft YaHei", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LJurusan.Location = New System.Drawing.Point(6, 92)
        Me.LJurusan.Name = "LJurusan"
        Me.LJurusan.Size = New System.Drawing.Size(50, 16)
        Me.LJurusan.TabIndex = 1
        Me.LJurusan.Text = "Jurusan"
        '
        'ENIM
        '
        Me.ENIM.Location = New System.Drawing.Point(106, 24)
        Me.ENIM.Name = "ENIM"
        Me.ENIM.Size = New System.Drawing.Size(98, 20)
        Me.ENIM.TabIndex = 1
        '
        'nama
        '
        Me.nama.AutoSize = True
        Me.nama.Font = New System.Drawing.Font("Microsoft YaHei", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.nama.Location = New System.Drawing.Point(6, 58)
        Me.nama.Name = "nama"
        Me.nama.Size = New System.Drawing.Size(40, 16)
        Me.nama.TabIndex = 1
        Me.nama.Text = "Nama"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft YaHei", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(6, 26)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(32, 16)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "NIM"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(354, 353)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "PROGRAM ENTRY DATA MAHASISWA"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents RbtPerempuan As RadioButton
    Friend WithEvents CmdProses As Button
    Friend WithEvents RbtLaki As RadioButton
    Friend WithEvents CmbJurusan As ComboBox
    Friend WithEvents LJenis As Label
    Friend WithEvents ENAMA As TextBox
    Friend WithEvents LJurusan As Label
    Friend WithEvents ENIM As TextBox
    Friend WithEvents nama As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
End Class
