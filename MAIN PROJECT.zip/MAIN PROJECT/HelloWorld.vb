﻿Public Class Form_HelloWorld
    Private Sub bPesan_Click(sender As Object, e As EventArgs) Handles bPesan.Click
        MsgBox("Hello World!")
        Label1.Text = "Anda Berhasil Klik 1x"
    End Sub
End Class