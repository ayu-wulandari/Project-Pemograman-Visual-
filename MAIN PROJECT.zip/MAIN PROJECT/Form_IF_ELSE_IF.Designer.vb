﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form_IF_ELSE_IF
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.chkKare = New System.Windows.Forms.CheckBox()
        Me.chkSoto = New System.Windows.Forms.CheckBox()
        Me.chkSate = New System.Windows.Forms.CheckBox()
        Me.BTampil = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'chkKare
        '
        Me.chkKare.AutoSize = True
        Me.chkKare.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.chkKare.Location = New System.Drawing.Point(50, 180)
        Me.chkKare.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.chkKare.Name = "chkKare"
        Me.chkKare.Size = New System.Drawing.Size(60, 21)
        Me.chkKare.TabIndex = 9
        Me.chkKare.Text = "Kare"
        Me.chkKare.UseVisualStyleBackColor = True
        '
        'chkSoto
        '
        Me.chkSoto.AutoSize = True
        Me.chkSoto.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.chkSoto.Location = New System.Drawing.Point(50, 140)
        Me.chkSoto.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.chkSoto.Name = "chkSoto"
        Me.chkSoto.Size = New System.Drawing.Size(59, 21)
        Me.chkSoto.TabIndex = 8
        Me.chkSoto.Text = "Soto"
        Me.chkSoto.UseVisualStyleBackColor = True
        '
        'chkSate
        '
        Me.chkSate.AutoSize = True
        Me.chkSate.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.chkSate.Location = New System.Drawing.Point(50, 98)
        Me.chkSate.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.chkSate.Name = "chkSate"
        Me.chkSate.Size = New System.Drawing.Size(59, 21)
        Me.chkSate.TabIndex = 7
        Me.chkSate.Text = "Sate"
        Me.chkSate.UseVisualStyleBackColor = True
        '
        'BTampil
        '
        Me.BTampil.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.BTampil.Location = New System.Drawing.Point(50, 226)
        Me.BTampil.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.BTampil.Name = "BTampil"
        Me.BTampil.Size = New System.Drawing.Size(128, 28)
        Me.BTampil.TabIndex = 6
        Me.BTampil.Text = "Tampilkan Pilihan"
        Me.BTampil.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label1.Location = New System.Drawing.Point(46, 68)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(113, 17)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Makanan Favorit"
        '
        'Form_IF_ELSE_IF
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(496, 395)
        Me.Controls.Add(Me.chkKare)
        Me.Controls.Add(Me.chkSoto)
        Me.Controls.Add(Me.chkSate)
        Me.Controls.Add(Me.BTampil)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form_IF_ELSE_IF"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form_IF_ELSE_IF"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents chkKare As CheckBox
    Friend WithEvents chkSoto As CheckBox
    Friend WithEvents chkSate As CheckBox
    Friend WithEvents BTampil As Button
    Friend WithEvents Label1 As Label
End Class
