﻿Public Class Form1
    Private Sub HelloWorldToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HelloWorldToolStripMenuItem.Click

        Form_HelloWorld.MdiParent = Me
        Form_HelloWorld.Show()

    End Sub

    Private Sub MessageBoxToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MessageBoxToolStripMenuItem.Click

        Form_MessageBox.MdiParent = Me
        Form_MessageBox.Show()

    End Sub

    Private Sub OperatorRelasiToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OperatorRelasiToolStripMenuItem.Click
        program_operator_relasi.MdiParent = Me
        program_operator_relasi.Show()
    End Sub

    Private Sub OperatorPerhitungan1ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OperatorPerhitungan1ToolStripMenuItem.Click
        Operator_Perhitungan.MdiParent = Me
        Operator_Perhitungan.Show()
    End Sub

    Private Sub ChangeKursToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ChangeKursToolStripMenuItem.Click
        ProgramChangeKurs.MdiParent = Me
        ProgramChangeKurs.Show()
    End Sub

    Private Sub OperatorPerhitungan2ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OperatorPerhitungan2ToolStripMenuItem.Click
        OperatorPerhitungan2.MdiParent = Me
        OperatorPerhitungan2.Show()



    End Sub

    Private Sub ConvertTipeDataToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ConvertTipeDataToolStripMenuItem.Click
        Form_ConvertTipeData.MdiParent = Me
        Form_ConvertTipeData.Show()
    End Sub

    Private Sub IfThenElseToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles IfThenElseToolStripMenuItem.Click
        if_Then_Else.MdiParent = Me
        if_Then_Else.Show()

    End Sub

    Private Sub IfElseIfEndIfRadiobuttonToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles IfElseIfEndIfRadiobuttonToolStripMenuItem.Click
        if_Elself_End_if_radioButton.MdiParent = Me
        if_Elself_End_if_radioButton.Show()
    End Sub

    Private Sub SelectCaseJurusanToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SelectCaseJurusanToolStripMenuItem.Click
        selectcaseJurusan.MdiParent = Me
        selectcaseJurusan.Show()
    End Sub

    Private Sub PerhitunganGajiKaryawanToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PerhitunganGajiKaryawanToolStripMenuItem.Click
        Perhitungan_Gaji.MdiParent = Me
        Perhitungan_Gaji.Show()

    End Sub

    Private Sub ProgramSPBUToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ProgramSPBUToolStripMenuItem.Click
        SPBU.MdiParent = Me
        SPBU.Show()

    End Sub

    Private Sub Pertemuan4ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles Pertemuan4ToolStripMenuItem.Click

    End Sub

    Private Sub SelectCaseNilaiToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SelectCaseNilaiToolStripMenuItem.Click
        select_case.MdiParent = Me
        select_case.Show()
    End Sub

    Private Sub PerhitunganNilaiAkhirDanPenentuanGradeToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PerhitunganNilaiAkhirDanPenentuanGradeToolStripMenuItem.Click
        perhitungan_nilai_akhir_dan_penentuan_G.MdiParent = Me
        perhitungan_nilai_akhir_dan_penentuan_G.Show()
    End Sub

    Private Sub IfElseIfEndIfComboboxToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles IfElseIfEndIfComboboxToolStripMenuItem.Click
        Form2.MdiParent = Me
        Form2.Show()
    End Sub

    Private Sub SelectCaseListBoxToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SelectCaseListBoxToolStripMenuItem.Click
        ListBox.MdiParent = Me
        ListBox.Show()
    End Sub

    Private Sub PerulanganForNextDateToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PerulanganForNextDateToolStripMenuItem.Click
        Pengulangan.MdiParent = Me
        Pengulangan.Show()
    End Sub

    Private Sub EntryDataMahasiswaToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EntryDataMahasiswaToolStripMenuItem.Click
        ProgramEntryDataMahasiswa.MdiParent = Me
        ProgramEntryDataMahasiswa.Show()
    End Sub

    Private Sub SelectCasePaketMakananToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SelectCasePaketMakananToolStripMenuItem.Click
        Select_Case_Paket_Makanan.MdiParent = Me
        Select_Case_Paket_Makanan.Show()

    End Sub

    Private Sub PertemuanToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PertemuanToolStripMenuItem.Click

    End Sub

    Private Sub PerulanganForNextInputToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PerulanganForNextInputToolStripMenuItem.Click
        ProgramPengulanganInput.MdiParent = Me
        ProgramPengulanganInput.Show()
    End Sub

    Private Sub PerulanganWhileEndWhileToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PerulanganWhileEndWhileToolStripMenuItem.Click
        Perulangan_While.MdiParent = Me
        Perulangan_While.Show()
    End Sub

    Private Sub PercabanganIfToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PercabanganIfToolStripMenuItem.Click
        Percabangan_If.MdiParent = Me
        Percabangan_If.Show()

    End Sub

    Private Sub PembayaranToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PembayaranToolStripMenuItem.Click
        Pembayaran.MdiParent = Me
        Pembayaran.Show()

    End Sub

    Private Sub TampilanDataToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TampilanDataToolStripMenuItem.Click
        Tampilan_Data.MdiParent = Me
        Tampilan_Data.Show()
    End Sub

    Private Sub PerulanganForNextStepToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PerulanganForNextStepToolStripMenuItem.Click
        perulangan_for_next___step__.MdiParent = Me
        perulangan_for_next___step__.Show()
    End Sub

    Private Sub PerulanganDoUntilLoopToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PerulanganDoUntilLoopToolStripMenuItem.Click
        perulanga_do_until___loop.MdiParent = Me
        perulanga_do_until___loop.Show()
    End Sub

    Private Sub PracticeOfArray01ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PracticeOfArray01ToolStripMenuItem.Click
        practice_of_array_01.MdiParent = Me
        practice_of_array_01.Show()
    End Sub

    Private Sub IfThenToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles IfThenToolStripMenuItem.Click
        Form_IF_THEN.MdiParent = Me
        Form_IF_THEN.Show()

    End Sub

    Private Sub IfElseIfEndIfCheckboxToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles IfElseIfEndIfCheckboxToolStripMenuItem.Click
        Form_IF_ELSE_IF.MdiParent = Me
        Form_IF_ELSE_IF.Show()

    End Sub

    Private Sub NestedIfToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles NestedIfToolStripMenuItem.Click
        Nested_IF.MdiParent = Me
        Nested_IF.Show()

    End Sub

    Private Sub PerulanganForNextToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PerulanganForNextToolStripMenuItem.Click
        Perulangan_For_Next.MdiParent = Me
        Perulangan_For_Next.Show()
    End Sub

    Private Sub BulanIndexToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles BulanIndexToolStripMenuItem.Click
        BulanIndex.MdiParent = Me
        BulanIndex.Show()
    End Sub
End Class
