﻿Public Class Form1
    Private Sub HelloWorldToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HelloWorldToolStripMenuItem.Click

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub SelectCasePaketMakananToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SelectCasePaketMakananToolStripMenuItem.Click

    End Sub
End Class
